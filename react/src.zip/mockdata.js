export const initialHistory = [];

